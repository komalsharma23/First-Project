package com.oodle.KomalSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KomalSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
